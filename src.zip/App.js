import './App.css';
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { Routes, Route, useNavigate} from 'react-router-dom';
import Service from './pages/service.js';
import Incident from './pages/incident';
import Mychart from './pages/mychart';
import Srchart from './pages/srchart';
import Inchart from './pages/inchart';
import Chchart from './pages/chchart';
import Prchart from './pages/prchart';
import Portallist from './pages/portallist';
import Assetchart from './pages/assetchart';
import Paging from './pages/paging';


function App() {
  let navigate = useNavigate();
  return (
    <div className="App">
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container>
          <Navbar.Brand onClick={()=>{navigate('/')}}>Staff Porket</Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="me-auto">
              <NavDropdown title="Service Mgt." id="collasible-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Serivce Request</NavDropdown.Item>
                <NavDropdown.Item onClick={()=>{navigate('/service')}}>Serivce view</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">Setting</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action/3.4">Reporting</NavDropdown.Item>
              </NavDropdown>
              <NavDropdown title="Incident Mgt." id="collasible-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Incident Request</NavDropdown.Item>
                <NavDropdown.Item onClick={()=>{navigate('/incident')}}>Incident view</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">Setting</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action/3.4">Reporting</NavDropdown.Item>
              </NavDropdown>
              <NavDropdown title="Change Mgt." id="collasible-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Change Request</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.2">Change view</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">Setting</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action/3.4">Reporting</NavDropdown.Item>
              </NavDropdown>
              <NavDropdown title="Asset Mgt." id="collasible-nav-dropdown">
                <NavDropdown.Item href="#action/3.1">Asset Request</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.2">Asset view</NavDropdown.Item>
                <NavDropdown.Item href="#action/3.3">Setting</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item href="#action/3.4">Reporting</NavDropdown.Item>
              </NavDropdown>
            </Nav>
            <Nav>
              <Nav.Link onClick={()=>{navigate('/paging')}}>Paging</Nav.Link>
              <Nav.Link eventKey={2} href="#memes">Charting</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      

      <Routes> 
        <Route path="/" element={<div>
          <table>
            <tbody>
              <tr>
                <td><Portallist /></td>
                <td>
                  <table>
                    <tbody>
                      <tr>
                        <td><Srchart /></td>
                        <td><Inchart /></td>
                      </tr>
                      <tr>
                        <td><Chchart /></td>
                        <td><Prchart /></td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              <tr>
                <td><Mychart /></td>
                <td> 
                  <div className="td_center"><Assetchart /></div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>} />
        <Route path="/service/*" element={<div> <Service /> </div>} />
        <Route path="/incident" element={<div> <Incident /> </div>} />
        <Route path="/paging" element={<div> <Paging /> </div>} />
        <Route path="*" element={<div>없는페이지</div>} /> 
      </Routes>
    </div>
  );
}

export default App;
