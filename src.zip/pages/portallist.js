
import data1 from '../data/servicedata'
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';

function Portallist() {
    let [data] = useState(data1);
  return (
    <div>
      <table id="table_full">
        <tbody >
          {
              data.map(function(a,i)
              {
                if(i<10){
                  return(
                    <DataMap data={data} i={i} key={i}/>
                  )
                } 
                return null;
 
              })
          }
        </tbody>
      </table>
    </div>
  )
}

function DataMap(props){
  let i = props.i;
  return(
          <tr>
              <td>{props.data[i].id}</td>
              <td>{props.data[i].type}</td>
              <td id="td_left">{props.data[i].title}</td>
              <td>{props.data[i].startday}</td>
            </tr>
          )
}

export default Portallist