import React from 'react'
import styled from 'styled-components';
import { Line } from 'react-chartjs-2';
import { Chart, registerables } from "chart.js"
Chart.register(...registerables)

const data = {
    labels: ['단순문의', '계정요청', '네트워크', 'IP요청', 'OA요청', '기타'],
    datasets: [
      {
        type: 'bar',
        label: '서비스요청',
        backgroundColor: 'rgb(68, 189, 251)', 
        data: [7, 2, 6, 4, 3, 6, 11],
      },
    ],
  };

const options = {
  spanGaps: true,
  maxBarThickness: 30,
  grouped: true,
  interaction: {
    mode: 'index',
  },
  plugins: {
    legend: {
      labels: {
        usePointStyle: true,
        padding: 10,
        font: {
          family: "'Noto Sans KR', 'serif'",
          lineHeight: 1,
        },
      }
    }
  }
};

const Srchart = () => {
  return (
    <Container>
      <Line type="line" data={data} options={options} />
    </Container>
  );
};

export default Srchart;

const Container = styled.div`
  width: 25vw;
  max-width: 450px;
  height: 20vw;
  max-height: 230px;
`;