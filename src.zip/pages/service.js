import Table from 'react-bootstrap/Table';
import srdata from '../data/servicedata'
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Routes, Route, Link, useNavigate, Outlet } from 'react-router-dom';
import { Navbar, Container, Nav, Row, Col} from 'react-bootstrap';
import Detail from '../pages/detail';
import '../App.css';
import Button from 'react-bootstrap/Button';


function Service() {
    let [data] = useState(srdata);
    const [search, setSearch] = useState("");
    const [search2, setSearch2] = useState("");
    const numChange=(e)=>{
      setSearch(e.target.value);
      console.log(e.target.value);
    }

    const nameChange=(e)=>{
      console.log(e.target.value);
    }
    const titleChange=(e)=>{
      console.log(e.target.value);
    }

    const OPTIONS = [
      { value: "", name: "-------------------------" },
      { value: "서비스요청", name: "서비스요청" },
      { value: "장애요청", name: "장애요청" },
      { value: "변경요청", name: "변경요청" },
    ];
    
    const SelectBox = (props) => {
      const typeChange = (e) => {
        setSearch2(e.target.value);
        console.log(e.target.value);
      };
    
      return (
        <select onChange={typeChange}>
          {props.options.map((option) => (
            <option
              key={option.value}
              value={option.value}
              defaultValue={props.defaultValue === option.value}
            >
              {option.name}
            </option>
          ))}
        </select>
      );
    };

  
  return (
    <div>
      <Container>    
        <Row>
          <Col md="1">요청번호</Col>
          <Col md="3"><input type="text" name="sr_num" value={search} onChange={numChange}></input></Col>
          <Col md="1">상세유형</Col>
          <Col md="3"><SelectBox options={OPTIONS}></SelectBox></Col>
          <Col md="1">요청자</Col>
          <Col md="3"><SelectBox options={OPTIONS} onChange={nameChange}></SelectBox></Col>
      </Row>
      <Row>
          <Col md="1">제목</Col>
          <Col md="11"><input type="text" name="sr_title" onChange={titleChange} ></input></Col>
      </Row>
      <Row>
        <Col md="1">작업상태</Col>
        <Col md="3"><input type="text" name="sr_state"></input></Col>
        <Col md="1">처리상태</Col>
        <Col md="3"><input type="text" name="sr_laststate"></input></Col>
        <Col md="1"></Col>
        <Col md="3"></Col>
      </Row>
      <Row>
        <Col md="1">요청일</Col>
        <Col md="3"><input type="text" name="sr_startday"></input></Col>
        <Col md="1">완료일</Col>
        <Col md="3"><input type="text" name="sr_endday"></input></Col>
        <Col md="4"></Col>
       </Row>
        <Row>
          <Col md="1"><Button variant="dark">검색</Button></Col>
        </Row>
      </Container> 

      <Routes> 
        <Route path="/" element={
          <div>
           <Container>          
              <Row>
                <Col md="1">요청번호</Col>
                <Col md="1">요청유형</Col>
                <Col md="1">요청자</Col>
                <Col md="5">요청제목</Col>
                <Col md="2">요청일시</Col>
                <Col md="2">종료일시</Col>
              </Row>
            </Container>   
            {
              data.map(function(a,i)
                {
                    return(
                        <DataMap data={data} i={i} search={search} search2={search2}/>
                    )
                })
              }
            </div>
        } />;
        <Route path="/detail/:id" element={<Detail data={data}/>} />;
        <Route path="*" element={<div>없는SR</div>} /> 

      </Routes>
       </div>
      );
}

function DataMap(props){
  let navigate = useNavigate();
  let i = props.i;
  let check= [false, false, false];
  if(props.search=="" || props.search==props.data[i].id){
    check[0]=true;
  };
  if(props.search2=="" || props.search2==props.data[i].type){
    check[1]=true;
  };


  if(check[0] && check[1]){
    return(
      <Container>
        <Row onClick={()=>{navigate('/service/detail/'+props.i)}}>
          <Col md="1">{props.data[i].id}</Col>
          <Col md="1">{props.data[i].type}</Col>
          <Col md="1">{props.data[i].name}</Col>
          <Col id = 'td_left' md="4">{props.data[i].title}</Col>
          <Col md="1">{props.data[i].state}</Col>
          <Col md="2">{props.data[i].startday}</Col>
          <Col md="2">{props.data[i].endday}</Col>
        </Row>
      </Container>
      )
  };

}


export default Service