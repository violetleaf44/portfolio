import Table from 'react-bootstrap/Table';
import data2 from '../data/incidentdata'
import { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Search from '../pages/search';

function Incident() {
    let [data] = useState(data2);
  return (
    <table>
      <Search />
    <Table striped bordered hover size="sm">
      <thead>
        <tr>
          <th>No.</th>
          <th>장애유형</th>
          <th>요청자</th>
          <th>제목</th>
          <th>시작일</th>
          <th>완료일</th>
        </tr>
      </thead>
      <tbody>
        {
            data.map(function(a,i)
            {
                return(
                    <tr>
                        <td>{data[i].id}</td>
                        <td>{data[i].type}</td>
                        <td>{data[i].name}</td>
                        <td>{data[i].title}</td>
                        <td>{data[i].startday}</td>
                        <td>{data[i].endday}</td>
                    </tr>
                )
            })
        }
      </tbody>
    </Table>
    </table>
  );
}

export default Incident