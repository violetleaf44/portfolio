import React from 'react';
import { useParams } from "react-router-dom";
import { useEffect, useState} from "react";
import { Navbar, Container, Nav, Row, Col} from 'react-bootstrap';

function Detail(props){
    let {id} = useParams();
    let 찾은데이터 = props.data.find(function(x){
        return x.id == id
    });
    let [tabdata,setTabdata] = useState(0);
    return(
        <div>
            <table>
                <tr>
                    <th>요청유형</th>
                    <th>요청자</th>
                    <th>요청ID</th>
                    <th>접수자</th>
                </tr>
                <tr>
                    <td>{props.data[id].type}</td>
                    <td>{props.data[id].name}</td>
                    <td>{props.data[id].id}</td>
                    <td></td>
                </tr>
                <tr>
                    <th>요청일</th>
                    <th>담당자</th>
                    <th>완료일</th>
                    <th></th>
                </tr>
                <tr>
                    <td>{props.data[id].startday}</td>
                    <td>{props.data[id].name}</td>
                    <td>{props.data[id].endday}</td>
                    <td></td>
                </tr>
                <tr>
                    <td id="td_left" colspan="4">요청제목</td>
                </tr>
                <tr>
                    <td id="td_left" colspan="4">{props.data[id].title}</td>
                </tr>
                <tr>
                    <td id="td_left" colspan="4">요청내용</td>
                </tr>
                <tr>
                    <td id="td_left" colspan="4">{props.data[id].title}</td>
                </tr>
                <tr>
                    <td colspan="4">
                    <Nav variant="tabs"  defaultActiveKey="link0">
                        <Nav.Item>
                        <Nav.Link onClick={()=>{
                                setTabdata(0)
                            }} eventKey="link0"> 첨부파일 </Nav.Link>
                        </Nav.Item>
                        <Nav.Item>
                        <Nav.Link onClick={()=>{
                                setTabdata(1)
                            }} eventKey="link1"> 연관 SR </Nav.Link>
                        </Nav.Item> <Nav.Item>
                        <Nav.Link onClick={()=>{
                                setTabdata(2)
                            }} eventKey="link2"> ㅇ </Nav.Link>
                        </Nav.Item>
                    </Nav>
                    <TabContent tabdata={tabdata} />
                    </td>
                </tr>
            </table>       
        </div>
    )
}

function TabContent({tabdata}){
    let [fade, setFade]=useState('')
     
    useEffect(()=>{
        setTimeout(()=>{ setFade('end')} ,100)

        return ()=>{
            setFade('')
        }
    },[tabdata])
    return(<div className={'start ' + fade}>
    {[<div>내용0</div>,<div>내용1</div>,<div>내용2</div>][tabdata]}
    </div>)
}



export default Detail