import srdata from '../data/servicedata'
import React, { useState } from "react";
import '../App.css';
import Pagination from "react-js-pagination";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const Paging = () => {
  const [page, setPage] = useState(1);
  const [data, setData] = useState(srdata);
  const [items, setItems] = useState(5);

  const handlePageChange = (page) => { setPage(page); };
  const itemChange = (e) => {
    setItems(Number(e.target.value))

  }
  console.log(items*(page-1), items*(page-1)+items)

  return (
    <div>
      <h2>API 연습</h2>
      <div>
        <select name="items" onChange={itemChange}>
          <option value="5">5개</option>
          <option value="10">10개</option>
          <option value="15">15개</option>
          <option value="20">20개</option>
        </select>
      </div>
      {/* <table>
      {data.slice(
        items*(page-1),
        items*(page-1)+items
      ).map((v,i) => {
        return (
          <tr>
          <td>{v.id}</td>
          <td>{v.type}</td>
          <td id="td_left">{v.title}</td>
          <td>{v.name}</td>
          <td>{v.state}</td>
          <td>{v.startday}</td>
          <td>{v.endday}</td>
        </tr>
        )
      })}
      </table> */}

      <Container>
      {data.slice(
        items*(page-1),
        items*(page-1)+items
      ).map((v,i) => {
        return (
          <Row>
            <Col md="1">{v.id}</Col>
            <Col md="1">{v.type}</Col>
            <Col md="1">{v.name}</Col>
            <Col id = 'td_left' md="4">{v.title}</Col>
            <Col md="1">{v.state}</Col>
            <Col md="2">{v.startday}</Col>
            <Col md="2">{v.endday}</Col>
        </Row>
        )
      })}
      </Container>

      <Pagination
        activePage={page}
        itemsCountPerPage={10}
        totalItemsCount={80}
        pageRangeDisplayed={5}
        prevPageText={"‹"}
        nextPageText={"›"}
        onChange={handlePageChange} />
    </div>
  )
};

export default Paging;
