import Button from 'react-bootstrap/Button';
import '../App.css';

function Search() {
  const numChange=(e)=>{
    console.log(e.target.value);
  }
  const typeChange=(e)=>{
    console.log(e.target.value);
  }
  const nameChange=(e)=>{
    console.log(e.target.value);
  }
  const titleChange=(e)=>{
    console.log(e.target.value);
  }

    return (
      <div>
        <table>
          <th>
            검색
          </th>
          <tr id="tr_spacing">
            <td id="td_right">요청번호</td>
            <td id="td_left"><input type="text" name="sr_num" onChange={numChange}></input></td>
            <td id="td_right">상세유형</td>
            <td id="td_left"><input type="text" name="sr_type" onChange={typeChange}></input></td>
            <td id="td_right">요청자</td>
            <td id="td_left"><input type="text" name="sr_name" onChange={nameChange}></input></td>
          </tr>
          <tr id="tr_spacing">
          <td id="td_right">제목</td>
            <td id="td_left" colspan="5"><input type="text" name="sr_title" onChange={titleChange}></input></td>
          </tr>
          <tr id="tr_spacing">
            <td id="td_right">작업상태</td>
            <td id="td_left"><input type="text" name="sr_state"></input></td>
            <td id="td_right">처리상태</td>
            <td id="td_left"><input type="text" name="sr_laststate"></input></td>
            <td></td>
            <td></td>
          </tr>
          <tr id="tr_spacing">
            <td id="td_right">요청일</td>
            <td id="td_left"><input type="text" name="sr_startday"></input></td>
            <td id="td_right">완료일</td>
            <td id="td_left"><input type="text" name="sr_endday"></input></td>
            <td></td>
            <td></td>
          </tr>
          <tr>
            <Button variant="dark">검색</Button>
          </tr>
        </table>
      </div>
    );
  }
  
  export default Search;